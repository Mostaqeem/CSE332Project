#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    // retrieving decimal values......
    ifstream File1;
    ofstream File2;
    string str;
    File1.open("assembly.txt");

    if(!File1)
    {
        cout << "File was not found" << endl;
        return 1 ;
    }
    //File1>>str;
    getline(File1,str);

    File1.close();
    int i=0,j=0,k;
    int a[3];
    while(str[i] != NULL)
    {
        if(str[i] == '$')
        {
            a[j] = str[i+1] - 48;
            j++;
        }
        k=0;
        if(str[i] == 'i')
        {
            a[j] = str[i+1] - 48;
        }
        i++;
    }

    //retrieving the opcode.....
    i =0;
    string op="";
    while(str[i] != ' ')
    {
        op += str[i];

        i++;
    }

    string arr = "";

    if(op == "add")
        arr += '0';
    else if(op == "sub")
        arr += '1';
    else if(op == "addi")
        arr += '2';
    else if(op == "subi")
        arr += '3';
    else if(op == "lw")
        arr += '4';
    else if(op == "sw")
        arr += '5';
    else if(op == "and")
        arr += '6';
    else if(op == "or")
        arr += '7';
    else{
        cout<<"Error//Please enter the opcode in lower case.";
    }


     //HEXADECIMAL conversion.........
         j = 0;
    while(j<4)
    {
        if(a[j]>9)
        {
            if(a[j] == 10)
                arr[j]='a';
            else if(a[j] == 11)
                arr[j]='b';
            else if(a[j] == 12)
                arr[j]='c';
            else if(a[j] == 13)
                arr[j]='d';
            else if(a[j] == 14)
                arr[j]='e';
            else if(a[j] == 15)
                arr[j]='f';
        }
        else
        arr += a[j] + 48;
        j++;
    }
    string outstr = arr;


    //writing into the file......

    File2.open("machine_lang_hex.txt");

    if(!File2)
    {
        cout << "File was not found" << endl;
        return 1 ;
    }
    File2<<arr;

    File2.close();
    cout<<"Success creating machine_lang_hex.txt \n";

    return 0;
}
